package test;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import nl.coralic.blog.ejb31.*;

import org.junit.Test;

public class TestItem
{
	@Test
	public void saveAndGetKlant() throws NamingException, InterruptedException
	{
		Map<String, Object> properties = new HashMap<String, Object>();
		properties.put(EJBContainer.MODULES, new File("target/classes"));
		properties.put("org.glassfish.ejb.embedded.glassfish.installation.root", "glassfish");
		properties.put(EJBContainer.APP_NAME, "coralic");
		EJBContainer c = EJBContainer.createEJBContainer(properties);
		Context ic = c.getContext();
		ItemService itemService = (ItemService) ic.lookup("java:global/coralic/ItemService");
		Item item = new Item();
		item.setItemName("testname");
		itemService.save(item);

		System.out.println("Get all items from DB and show itemname for the first one: " + itemService.getItems().get(0).getItemName());
		
		c.close();
	}
}

