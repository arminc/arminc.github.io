package nl.coralic.blog.ejb31;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class ItemService
{
	@PersistenceContext(unitName = "itemDataBase")
	EntityManager em;

	public void save(Item item)
	{
		this.em.persist(item);
	}
	
	public Item findItem(long id)
	{
		return this.em.find(Item.class, id);
	}

	public List<Item> getItems()
	{
		return this.em.createNamedQuery(Item.findAll).getResultList();
	}

	public void delete(long itemid)
	{
		Item item = findItem(itemid);
		if (item != null)
		{
			em.remove(item);
		}
	}
}
