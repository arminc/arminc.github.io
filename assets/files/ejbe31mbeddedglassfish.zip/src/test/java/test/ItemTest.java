package test;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import nl.coralic.blog.ejb31.Item;
import nl.coralic.blog.ejb31.ItemService;

import org.glassfish.api.embedded.LifecycleException;
import org.junit.Test;

public class ItemTest {
	@Test
	public void addItem() throws NamingException, LifecycleException
	{
		InitialContext ic = new InitialContext();
		ItemService itemService = (ItemService)ic.lookup("java:global/ejbembeddedtest-0.0.1-SNAPSHOT/ItemService");
		Item item = new Item();
		item.setItemName("testname");
		itemService.save(item);

		System.out.println("Get all items from DB and show itemname for the first one: " + itemService.getItems().get(0).getItemName());
		
	}

}
