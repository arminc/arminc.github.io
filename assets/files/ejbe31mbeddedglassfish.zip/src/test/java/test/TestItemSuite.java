package test;

import java.io.File;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.glassfish.api.ActionReport;
import org.glassfish.api.admin.CommandRunner;
import org.glassfish.api.admin.ParameterMap;
import org.glassfish.api.deployment.DeployCommandParameters;
import org.glassfish.api.embedded.ContainerBuilder;
import org.glassfish.api.embedded.EmbeddedDeployer;
import org.glassfish.api.embedded.EmbeddedFileSystem;
import org.glassfish.api.embedded.LifecycleException;
import org.glassfish.api.embedded.Server;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses( { ItemTest.class })
public class TestItemSuite
{
	public static Server server;
	private static EmbeddedDeployer embdeployer;

	@SuppressWarnings("unchecked")
	@BeforeClass
	public static void setUp() throws LifecycleException
	{

		Server.Builder builder = new Server.Builder("coralicglassfish");
		EmbeddedFileSystem.Builder efsb = new EmbeddedFileSystem.Builder();
		efsb.installRoot(new File("target/glassfish/installroot"));
		efsb.instanceRoot(new File("target/glassfish/instanceroot"));
		efsb.autoDelete(true);
		EmbeddedFileSystem efs = efsb.build();
		builder.embeddedFileSystem(efs);
		
		Server server = builder.build();
		
		ContainerBuilder ejbContainer = server.createConfig(ContainerBuilder.Type.ejb);
		server.addContainer(ejbContainer);

		server.start();

		String com = "create-jdbc-connection-pool";
		ParameterMap props = new ParameterMap();
		props.add("datasourceclassname", "org.apache.derby.jdbc.EmbeddedDataSource");
		props.add("restype", "javax.sql.DataSource");
		props.add("ping", "true");
		props.add("property", "ConnectionAttributes=create\\=true:DatabaseName=target/itemDataBase");
		props.add("DEFAULT", "itemDataBase");
		CommandRunner run = server.getHabitat().getComponent(CommandRunner.class);
		ActionReport rep = server.getHabitat().getComponent(ActionReport.class);
		run.getCommandInvocation(com, rep).parameters(props).execute();

		String command = "create-jdbc-resource";
		ParameterMap par = new ParameterMap();
		par.add("connectionpoolid", "itemDataBase");
		par.add("jndi_name", "jdbc/itemDataBase");
		CommandRunner runner = server.getHabitat().getComponent(CommandRunner.class);
		ActionReport report = server.getHabitat().getComponent(ActionReport.class);
		runner.getCommandInvocation(command, report).parameters(par).execute();

		File fileToDeploye = new File("target/ejbembeddedtest-0.0.1-SNAPSHOT.jar");
		EmbeddedDeployer deployer = server.getDeployer();
		DeployCommandParameters params = new DeployCommandParameters();
		deployer.deploy(fileToDeploye, params);

	}

	public static Test suite()
	{
		TestSuite suite = new TestSuite("Test");
		// $JUnit-BEGIN$
		// $JUnit-END$
		return suite;
	}

	@AfterClass
	public static void tearDown() throws LifecycleException
	{
		if (embdeployer != null)
		{
			embdeployer.undeployAll();
		}
		if (server != null)
		{
			server.stop();
		}

	}

}
