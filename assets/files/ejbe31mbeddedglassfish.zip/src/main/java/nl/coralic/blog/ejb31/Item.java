package nl.coralic.blog.ejb31;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name=Item.findAll,query="SELECT item from Item item")
public class Item
{
	public final static String findAll = "nl.coralic.blog.ejb31.findAll";
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long itemid;
	
	private String itemName;

	public String getItemName()
	{
		return itemName;
	}

	public void setItemName(String itemName)
	{
		this.itemName = itemName;
	}

	public Long getItemid()
	{
		return itemid;
	}
	
	
}

