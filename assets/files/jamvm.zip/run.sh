#!
#/bin/bash
./jamvm -Xbootclasspath:./lib/classes.zip:./lib/glibj.zip:. -classpath . -Dgnu.classpath.boot.library.path=./lib HelloWorldApp
